// util.c: provided functions to ease parsing and pausing.

#include "commando.h"

int main() {
  setvbuf(stdout, NULL, _IONBF, 0); // Turn off output buffering
  while(1) {
    printf("%s", "@>");
    char buf[MAX_LINE];
    fgets(buf,MAX_LINE,stdin);
    if(strncmp(buf,"",1) == 0) {
      printf("End of input");
      break;
    }
    char * tokens[MAX_LINE];
    int *ntok = 0;
    parse_into_tokens(buf,tokens,ntok);
    if(ntok == 0) {
      break;
    }
    for(int i = 0; i < *ntok-1; i++) {
      if((strncmp(tokens[i],"help",4)) == 0)
	{
	  printf("COMMANDO COMMANDS\n");
	  printf("help               : show this message\n");
	  printf("exit               : exit the program\n");
	  printf("list               : list all jobs that have been started giving information on each\n");
	  printf("pause nanos secs   : pause for the given number of nanseconds and seconds\n");
	  printf("output-for int     : print the output for given job number\n");
	  printf("output-all         : print output for all jobs\n");
	  printf("wait-for int       : wait until the given job number finishes\n");
	  printf("wait-all           : wait for all jobs to finish\n");
printf("command arg1 ...   : non-built-in is run as a job\n");
	}
      else if((strncmp(tokens[i],"exit",4)) == 0) {
	    exit(0);
      }
      else if((strncmp(tokens[i],"list",4)) == 0) {
      }
      else if((strncmp(tokens[i],"pause nano secs",15)) == 0) {
	//pause_for(tokens[i+1],tokens[i+2]);
	//i +=2;
      }
      else if((strncmp(tokens[i],"output-for int",14)) == 0) {
      }
      else if((strncmp(tokens[i],"output-all",10)) == 0) {
      }
      else if((strncmp(tokens[i],"wait-for int",12)) == 0) {
      }
      else if((strncmp(tokens[i],"wait-all",8)) == 0) {
      }
      else if((strncmp(tokens[i],"command arg1",10)) == 0) {
      }
    }
    
  }		  
 return 0;	  
    
}
